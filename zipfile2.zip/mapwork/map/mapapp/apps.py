from django.apps import AppConfig


class MapappConfig(AppConfig):
    name = 'mapapp'
