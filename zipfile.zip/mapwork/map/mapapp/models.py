from django.db import models

# Create your models here.
class latlng(models.Model):
    latitude=models.FloatField()
    longitude=models.FloatField()
